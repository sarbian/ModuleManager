 _______  _______  _______  _______ _________ _______ _________ _______  _______          
(  ____ )(  ____ \(       )(  ___  )\__   __/(  ____ \\__   __/(  ____ \(  ____ \|\     /|
| (    )|| (    \/| () () || (   ) |   ) (   | (    \/   ) (   | (    \/| (    \/| )   ( |
| (____)|| (__    | || || || |   | |   | |   | (__       | |   | (__    | |      | (___) |
|     __)|  __)   | |(_)| || |   | |   | |   |  __)      | |   |  __)   | |      |  ___  |
| (\ (   | (      | |   | || |   | |   | |   | (         | |   | (      | |      | (   ) |
| ) \ \__| (____/\| )   ( || (___) |   | |   | (____/\   | |   | (____/\| (____/\| )   ( |
|/   \__/(_______/|/     \|(_______)   )_(   (_______/   )_(   (_______/(_______/|/     \|

Name: RemoteTech: Relay Network for KSP.
Version: 0.5.0.1
Author: JDP
Based on the Satellite Relay Network plugin by The_Duck

This plugin is free to use and modify as long as the original authors are credited.
This plugin, and derivatives thereof, may only be hosted on kerbalspaceport.com.

Changelog:

V 0.5.0.1

� Added target-tracking dishes.

� Added custom aeurodynamic model for shrapnel created if tracking dishes break apart under high speed.

� Added a timing field in the attitude computer akin to the field in the throttle computer.

� tweaked the time input field to now allow you to input days (dd:hh:mm:ss).

� Added support for throttle increment controls.

� Fixed issue where antennae breaking off at very high speed could cause game to lag.

� Added multithreading in relay calculations and tweaked calculation load to give higher performance.


V 0.5.0.0

� Rewrote entire plugin to use only PartModules.

� Expanded the RemoteTech animation modules to allow for multiple simultaneous animations, inter-module events and looped animations.

� Rewrote the modding interface to use only KSPfields and KSPevents.

� Added a new RemoteCore handler to run parallel with vessel handling.

� Added rover mode in the flight computer.

� Added remote access to other RT vessel's flight computers.

� Added MechJeb 2.x compatability.

� Tweaked loss-of-signal behaviour.

� Added the MicroSat.

� Added the AeroProbe.


V 0.4.0.4

� Fixed the gear toggling bug introduced in KSP 0.18.4, and exacerbated by 0.19.

� Fixed some more remaining bugs in input lock removal.

� Fixed an exploit with maneuver nodes that would allow circumventing signal delays.

� Added a timing feature to the throttle flight computer.

� Added signal delay to stock rover controls.

� Rebalanced Parts.


V 0.4.0.3

� Added delayed ActionGroup activation.

� Fixed some remaining bugs in input lock removal.

� Tweaked the way HoldSAS is implemented

� Added a failsafe to the persistence loader. Now it clamps window positions to allways be within the screen.


V 0.4.0.2

� Integrated docking mode in the input and event handler fixing a lot of bugs.

� Added holdSAS to the event handler.

� Tweaked the throttle autopilot to calculate directional speed, making it more compatible with maneuver nodes.

� Added a new part; the MegaStrut. A massive strut riddled with attachment nodes. This should help out a lot in station building.

� Added a small cheat. Find it if you can.


V 0.4.0.1

� Fixed a bug in the animation module that caused antenna and dish ranges to be saved incorectly to the persistence file.

� Fixed a couple of activation issues that arise when undocking/docking. Still haven't fixed them all though.


V 0.4.0.0

� A major update to make RemoteTech 0.18 compatible.

� Tweaked the flight computer to more acurately handle PartModules.

� Changed the naming of the two part classes to better comply with their new roles in 0.18.

� Added animation module.

� Added Maneuver Node functionality to the autopilot.

� Added power consumption to all RemoteTech parts.


V 0.3.5.5

� Fixed the staging delay method so it doesn't disable staging in other ships.

� Fixed MechJeb compatability with integrated RemoteTech KillRot.


V 0.3.5.4

� Tweaked the delay method to also delay stage activation.

� Added custom RemoteTech icons.

� Implemented attitude control in unfocused vessels.

� Added delta-V mode in the throttle flight computer.

� Fixed surface attach on the interplanetary class dish.

� Fixed the issue where local control would be reset after decoupling debris.


V 0.3.5.3

� Implemented a new debris activation method pioneered by Zool. Staging is now supported in remote controlled debris.

� Implemented r4m0ns Smart A.S.S. code in a new flight computer. You can now remotely tell the computer which attitude to maintain and how long to burn the engine at a certain percentage.

� Revamped the list of targets in the settings menu. Now it's more obvious what is a vessel, planet or moon, and what's orbiting what.

� Optimized the way antenna states are saved and handled. This will not break compatability, but you will need to cycle through all your satellites to reset their savestates.

� Added in-game stat menus for all RemoteTech Parts

� Added a context menu, so the graphical menus can be hidden. It's also now possible to turn on inverse staging. This somewhat fixes an annoyance in some setups of activated and staged debris.

� Added persistence in window positions and which windows are open by default.


V 0.3.5.2

� Fixed compatability with joystick throttle. Bought a joystick to test it this time.

� Added compatability with MechJeb. Now MechJeb will be able to activate local control.

� Added support for crewable CommandPods that don't spawn crew in the RemotePod class.

� Added in-game stats drawn from the part config file.


V 0.3.5.1

� Changed the version naming convention to comply with kerbal.net standards.

� Made it possible to RemoteCommand crewable vessels without any crew on board.

� Hopefully fixed compatability with axis controls for throttle. I Don't currently have a way to test it though.


V 0.35:

� Applied the 0.17 compatability fixes developed by community members.

� fixed an exploit that could give zero delay at interplanetary distances.

� fixed the buggy throttle controls introduced in 0.17.


V 0.34:

� Fixed a lag issue with the "list comsats" submenu.

� Added two extra parts; Satellite Dish - Interplanetary class and Dipole Antenna. Both where made by rkman.


V 0.33:

� Added detailed satellite tracking in the "list Comsats" submenu, only satellites that have a signal path to the active Vessel are now editable, other satellites are colored red.

� Added the ability to point a satellite dish at an antenna, with a x2 range bonus for the antenna.

� Added a config file where you can edit the speed of light, number of crew needed for RemoteCommand and toggling detailed satellite tracking.

� Added an interface for use by other modders.


V 0.32:

� Fixed the staging setup on a mothership being reset after decoupling a RemoteControlled Vessel.

� Semi-fixed the issue where liquid engines would go dead if placed on top of the decoupler from which a RemoteControlled Vessel is decoupled.

� Gave the settings menu another overhaul so now it exactly matches the way the game handles the Relay Network.




List of known bugs:

� Renaming a Vessel in the settings utility only works for loaded Vessels, unloaded Vessels don't keep their edited name and revert upon next load.

� There is a visual glitch causing the visual representation of the signal path to be irratic at times, this is purely visual though and shouldn't affect gameplay.