﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

using ModuleManager;

namespace DeadlyReentry
{
	public class ModuleAeroReentry: PartModule
	{
		[KSPField(isPersistant = false, guiActive = false, guiName = "shockwave", guiUnits = "C",   guiFormat = "F3")]
		public float shockwave;

		[KSPField(isPersistant = false, guiActive = true, guiName = "temperature", guiUnits = "C",   guiFormat = "F3")]
		public float displayTemperature;

		public override void OnUpdate ()
		{
			Fields ["shockwave"].guiActive = ReentryPhysics.debugging;

			if(ReentryPhysics.afx.FxScalar > 0) {
				Vector3 velocity = (part.Rigidbody.GetPointVelocity(part.transform.position) + Krakensbane.GetFrameVelocityV3f() - Krakensbane.GetLastCorrection() * TimeWarp.fixedDeltaTime);
				shockwave = velocity.magnitude - 275;
				bool shielded;
				if(part.Modules.Contains ("FARBaseAerodynamics")) {
					shielded = part.Modules["FARBaseAerodynamics"].Fields.GetValue<bool>("isShielded");
					Fields ["isShielded"].guiActive = ReentryPhysics.debugging;
				}
				else
				{
					Ray ray;
					ray.direction = velocity.normalized;//(p.Rigidbody.GetPointVelocity(p.transform.position) + Krakensbane.GetFrameVelocityV3f() - Krakensbane.GetLastCorrection() * TimeWarp.fixedDeltaTime).normalized;
					ray.origin = part.transform.position;
					shielded = Physics.Raycast(ray, 10);
				}
				if (!shielded)
					part.temperature += ReentryPhysics.TemperatureDelta (vessel.atmDensity, shockwave, part.temperature);
			}
			displayTemperature = part.temperature;

		}

	}

	public class ModuleHeatShield: ModuleAeroReentry
	{
		/*

MODULE {
	direction = 1.0, 0, 0
	reflective = 0.05 // 5% of the heat will be reflected away if the shield is head-on
	ablative = "AblativeShielding" // uses AblativeShielding resource
	ablative_factor = 0.5 // for each degree celcius of temperature to add, 0.5 units of AblativeShielding will be consumed when shield is head-on
	ablative_efficiency = 0.9 // for each 0.5 units of AblativeShielding consumed, 0.9 degrees celcius will be mitigated
}
	*/

		[KSPField(isPersistant = false, guiActive = false, guiName = "angle", guiUnits = " ", guiFormat = "F3")]
		public float dot;


		[KSPField(isPersistant = true)]
		public int deployAnimationController;

		[KSPField(isPersistant = true)]
		public Vector3 direction;

		[KSPField(isPersistant = true)]
		public float reflective;

		[KSPField(isPersistant = true)]
		public string ablative = "AblativeShielding";

		[KSPField(isPersistant = true)]
		public FloatCurve loss = new FloatCurve();

		[KSPField(isPersistant = true)]
		public FloatCurve dissipation = new FloatCurve();

		private bool canShield {
			get {
				if(!part.Modules.Contains ("ModuleAnimateGeneric"))
					return true;
				return deployAnimationController == ((ModuleAnimateGeneric) part.Modules["ModuleAnimateGeneric"]).animTime;
			}
		}

		public override string GetInfo()
		{
			string s = "Active Heat Shield";
			if (direction.x != 0 || direction.y != 0 || direction.z != 0)
				s += " (directional)";
			return s;
		}

		public override void OnUpdate ()
		{
			//			shield.AtmosphericHeat(velocity, shockwave_temperature);
			Fields ["dot"].guiActive = ReentryPhysics.debugging;
			Fields ["shockwave"].guiActive = ReentryPhysics.debugging;

			if(ReentryPhysics.afx.FxScalar > 0) {
				Vector3 velocity = (part.Rigidbody.GetPointVelocity(part.transform.position) + Krakensbane.GetFrameVelocityV3f() - Krakensbane.GetLastCorrection() * TimeWarp.fixedDeltaTime);
				shockwave = velocity.magnitude - 275;
				bool shielded;
				if(part.Modules.Contains ("FARBaseAerodynamics"))
					shielded = part.Modules["FARBaseAerodynamics"].Fields.GetValue<bool>("isShielded");
				else
				{
					Ray ray;
					ray.direction = velocity.normalized;//(p.Rigidbody.GetPointVelocity(p.transform.position) + Krakensbane.GetFrameVelocityV3f() - Krakensbane.GetLastCorrection() * TimeWarp.fixedDeltaTime).normalized;
					ray.origin = part.transform.position;
					shielded = Physics.Raycast(ray, 10);
				}
				if (!shielded)
				{
					if(!canShield)// Shielded Clamp-O-Trons and other parts that have an 'open' and 'shielded' state
						dot = -1; 

					else if (direction.magnitude == 0) // an empty vector means the shielding exists on all sides
						dot = 1; 
					else // check the angle between the shock front and the shield
						dot = Vector3.Dot (velocity.normalized, part.transform.TransformDirection(direction).normalized);
					
					float temp = ReentryPhysics.TemperatureDelta (part.vessel.atmDensity, shockwave, part.temperature);
					
					if (dot > 0 && temp > 0) {
						//radiate away some heat
						float rad = temp * dot * reflective;
						temp -= rad;
						if(loss.Evaluate(shockwave) > 0
						   && part.Resources.Contains (ablative)) {
							// ablate away some shielding
							float ablation = dot * loss.Evaluate(shockwave) * TimeWarp.deltaTime;
							if(part.Resources[ablative].amount < ablation)
								ablation = (float) part.Resources[ablative].amount;
							// wick away some heat with the shielding
							part.Resources[ablative].amount -= ablation;
							temp -= dissipation.Evaluate(part.temperature) * ablation;
						}
					}
					part.temperature += temp;

				}
			}
			displayTemperature = part.temperature;			
		}
	}


	[KSPAddon(KSPAddon.Startup.Flight, false)]
    public class ReentryPhysics : MonoBehaviour
    {
		private static AerodynamicsFX _afx;

        public static AerodynamicsFX afx {
			get {
				if (_afx == null) {
					GameObject fx = GameObject.Find ("FXLogic");
					if (fx != null) {
						_afx = fx.GetComponent<AerodynamicsFX> ();
					}
				}
				return _afx;
			}
		}

        public static float Multiplier = 20.0f;
        public static float Exponent = 1.0f;

		public static float startThermal = 800.0f;
		public static float fullThermal = 1150.0f;
        public static bool debugging = false;
        protected Rect windowPos = new Rect(100, 100, 0, 0);

		public static float TemperatureDelta(double density, float temp1, float temp2)
		{
			if (temp1 < temp2 || afx == null || afx.airDensity == 0)
				return 0;
			return (float)Math.Pow (density * Math.Abs(temp1 - temp2) * Multiplier, ReentryPhysics.Exponent) * TimeWarp.deltaTime;
		}

        public void OnGUI()
        {
            if (debugging)
            {
                windowPos = GUILayout.Window("DeadlyReentry".GetHashCode(), windowPos, DrawWindow, "Deadly Reentry 2.0 Setup");
            }
        }

		private void FixAeroFX(AerodynamicsFX aeroFX)
		{
			if (afx.velocity.magnitude < startThermal) // approximate speed where shockwaves begin visibly glowing
				afx.state = 0;
			else if (afx.velocity.magnitude >= fullThermal)
				afx.state = 1;
			else
				afx.state = (afx.velocity.magnitude - startThermal) / (fullThermal - startThermal);
		}

		public void FixedUpdate()
		{
			FixAeroFX (afx);
		}

		public void LateUpdate()
		{
			FixAeroFX (afx);
		}

		public void Start()
		{

		}

        public void Update()
        {
            if (Input.GetKeyDown(KeyCode.R) && Input.GetKey(KeyCode.LeftAlt) && Input.GetKey(KeyCode.D))
            {
                debugging = !debugging;
            }

            if (FlightGlobals.ready)
            {
                if ((afx != null))
                {
					FixAeroFX(afx);
				
					foreach (Vessel vessel in FlightGlobals.Vessels) 
					{
						if(vessel.loaded)// && afx.FxScalar > 0)
						{
		                    foreach (Part p in vessel.Parts)
		                    {
								if(!(p.Modules.Contains ("ModuleAeroReentry") || p.Modules.Contains ("ModuleHeatShield")))
									ModuleManager.ModuleManager.Awaken (p.AddModule ("ModuleAeroReentry"));

							}
                        }
                    }
                }
            }
        }

        public void DrawWindow(int windowID)
        {
            GUIStyle buttonStyle = new GUIStyle(GUI.skin.button);
            buttonStyle.padding = new RectOffset(5, 5, 3, 0);
            buttonStyle.margin = new RectOffset(1, 1, 1, 1);
            buttonStyle.stretchWidth = false;
            buttonStyle.stretchHeight = false;

            GUIStyle labelStyle = new GUIStyle(GUI.skin.label);
            labelStyle.wordWrap = false;

            GUILayout.BeginVertical();

            GUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            if (GUILayout.Button("X", buttonStyle))
            {
                debugging = false;
            }
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("Exponent:", labelStyle);
            string newExponent = GUILayout.TextField(Exponent.ToString(), GUILayout.MinWidth(100));
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("Multiplier:", labelStyle);
            string newMultiplier = GUILayout.TextField(Multiplier.ToString(), GUILayout.MinWidth(100));
            GUILayout.EndHorizontal();

			GUILayout.BeginHorizontal();
			GUILayout.Label("F/X Transition", labelStyle);
			GUILayout.EndHorizontal();

			GUILayout.BeginHorizontal();
			GUILayout.Label("Begin at:", labelStyle);
			string newThermal = GUILayout.TextField(startThermal.ToString(), GUILayout.MinWidth(100));
			GUILayout.Label("m/s", labelStyle);
			GUILayout.EndHorizontal();

			GUILayout.BeginHorizontal();
			GUILayout.Label("Begin at:", labelStyle);
			string newThermalFull = GUILayout.TextField(fullThermal.ToString(), GUILayout.MinWidth(100));
			GUILayout.Label("m/s", labelStyle);
			GUILayout.EndHorizontal();

            GUILayout.EndVertical();

            GUI.DragWindow();

            if (GUI.changed)
            {
                float newValue;
                if (float.TryParse(newExponent, out newValue))
                {
                    Exponent = newValue;
                }

                if (float.TryParse(newMultiplier, out newValue))
                {
                    Multiplier = newValue;
                }
				if (float.TryParse(newThermal, out newValue))
				{
					startThermal = newValue;
				}
				if (float.TryParse(newThermalFull, out newValue))
				{
					fullThermal = newValue;
				}
			}
        }
    }
}
