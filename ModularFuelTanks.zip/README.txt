Ialdabaoth's Modular Fuel Tanks (Advanced Version), v0.9

=========== INSTALLATION ============
Put these files into {KSP}/GameData, like so:

{KSP}/GameData/ModuleManager.dll
{KSP}/GameData/Ialdabaoth/KSPX_modularFuelTanks.cfg
{KSP}/GameData/Ialdabaoth/KW_modularFuelTanks.cfg
{KSP}/GameData/Ialdabaoth/Squad_modularFuelTanks.cfg
{KSP}/GameData/Ialdabaoth/Plugins/ModularFuelTanks.dll
{KSP}/GameData/Ialdabaoth/Resources/TankTypes.cfg

============ HOW TO USE =============

Select a modular Fuel Tank (most stock, KW, and KSPX containers are now modular). 

Go to the Action Group editor.

Click on your fuel tank.

A menu will appear below the Action Group list that allows you to configure the tank.


========= HOW TO CUSTOMIZE ==========

If you want to add a tank to a part, create a new .cfg file anywhere in /GameData, then add the following lines:

@PART[PartName]
{
  MODULE 
  {
    name = ModuleFuelTanks
    volume = 800
    type = Default
  }
}

This will create an 800-volume tank, and configure the part to use the Default configuration. There are four configurations defined: Default, Cryogenic, Structural, and Fuselage.

Default is for rockets, and starts out full of 45% LiquidFuel/55% Oxidizer.
Fuselage is for spaceplanes, and starts out full of 100% LiquidFuel.
Structural is for nose cones and other parts, and starts out empty.
Cryogenic is currently the same as Default, but is provided for future expansion.

If you want to add a new tank type, add the following lines to your .cfg file:

TANK_DEFINITION
{
	name = MyCryoTank
	basemass = 0.00015 * volume
	TANK
	{
	   name = LiquidH2
	   efficiency = 0.99
	   mass = 0.0
	   temperature = -253
	   loss_rate = 0.0000000002
	   amount = 0.73 * volume
	   maxAmount = 0.73 * volume
	   note = (requires insulation)
	} 
	TANK
	{
	   name = LiquidOxygen
	   efficiency = 1.0
	   mass = 0.000475
	   temperature = -183
	   loss_rate = 0.00000000005
	   amount = 0.27 * volume
	   maxAmount = 0.27 * volume
	} 
	TANK
	{
	  name = LiquidFuel
	  efficiency = 1.0
	  mass = 0.0005
	  amount = 0.0
	  maxAmount = 0.0
	}
	TANK
	{
	  name = Oxidizer
	  efficiency = 1.0
	  mass = 0.0005
	  amount = 0.0
	  maxAmount = 0.0
	}
	TANK
	{
	  name = MonoPropellant
	  efficiency = 1.0
	  mass = 0.000625
	  amount = 0.0
	  maxAmount = 0.0
	}
	TANK
	{
	  name = XenonGas
	  efficiency = 0.99
	  mass = 0.000625
	  amount = 0.0
	  maxAmount = 0.0
	  note = (pressurized)
	}
}



"name" is how you refer to your tank, so if you do
MODULE
{
  name = ModuleFuelTanks
  type = MyCryoTank
  volume = 800
}

it will load a tank of your type.

"basemass" is the dry mass of your tank part. Note that this can (and probably should) be computed from volume.

TANK {} nodes define what resources the tank can hold. within a TANK node:

"name" is the name of the resource that it holds.
"efficiency" is how much of the available volume goes to the resource, as opposed to bulky pumps or insulation or pressurization or whatever.
"mass" is how much additional dry mass is added to the part per volume unit. Do not multiply this by volume; this is done automatically.
"amount" and "maxAmount" are how much of this resource the tank starts with by default, you can (and probably should) multiply this by volume.
"note" is a line of text displayed in the VAB to tell the user about any particular quirks of this resource tank.
"temperature" is the temperature (in degrees celsius) that the resource will start boiling off.
"loss_rate" is the fraction of the tank lost per second, per degree centigrade that the part exceeds that temperature.

You can of course modify TANK_DEFINITION nodes just like anything else, like so:

@TANK_DEFINITION[Default]
{
   @TANK[XenonGas]
   {
     @efficiency = 1.0
   }
   TANK
   {
     name = Kethane
     efficiency = 1.0
     mass = 0
     amount = 0
     maxAmount = 0
   }
}