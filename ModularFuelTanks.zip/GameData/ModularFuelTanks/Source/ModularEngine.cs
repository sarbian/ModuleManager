using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization.Formatters.Binary;

using UnityEngine;

using KSP;

namespace FuelModule
{
	public class ModuleEngineConfigs : PartModule
	{
		[KSPField(isPersistant = true)] 
		public string configuration = "";
		[KSPField(isPersistant = true)] 
		public bool modded = false;
		
		public List<ConfigNode> configs;
		public ConfigNode config;
		
		public override void OnAwake ()
		{
			if(configs == null)
				configs = new List<ConfigNode>();
		}
		
		public override string GetInfo ()
		{
			string info = "\nAlternate configurations:\n";
			foreach (ConfigNode config in configs) {
				if(!config.GetValue ("name").Equals (configuration)) {
					FloatCurve isp = new FloatCurve();
					isp.Load (config.GetNode ("atmosphereCurve"));
					info += "   " + config.GetValue ("name") + "\n    ("
						  	+ config.GetValue ("maxThrust") + " Thrust, " 
							+ isp.Evaluate (isp.maxTime).ToString() + "-" 
						  	+ isp.Evaluate (isp.minTime).ToString() + "Isp)\n";
				}
				
				
			}
			return info;
		}
		
		public void OnGUI()
		{
			EditorLogic editor = EditorLogic.fetch;
			if (!HighLogic.LoadedSceneIsEditor || !editor || editor.editorScreen != EditorLogic.EditorScreen.Actions) {
				return;
			}
			
			if (EditorActionGroups.Instance.GetSelectedParts ().Contains (part)) {
				Rect screenRect = new Rect(0, 365, 430, (Screen.height - 365));
				GUILayout.Window (part.name.GetHashCode (), screenRect, engineManagerGUI, "Configure " + part.partInfo.title);
			}
		}
		
		public override void OnLoad (ConfigNode node)
		{
			base.OnLoad (node);
			if (configs == null)
				configs = new List<ConfigNode> ();
			else
				configs.Clear ();
			
			foreach (ConfigNode subNode in node.GetNodes ("CONFIG")) {
				ConfigNode newNode = new ConfigNode("CONFIG");
				subNode.CopyTo (newNode);
				configs.Add (newNode);
				if(newNode.GetValue ("name").Equals (configuration)) {
					config = new ConfigNode("MODULE");
					subNode.CopyTo (config);
					config.name = "MODULE";
					config.SetValue ("name", "ModuleEngines");
				}
			}
		}
		
		public override void OnSave (ConfigNode node)
		{
			foreach (ConfigNode subNode in configs) {
				node.AddNode (subNode);
			}
			base.OnSave (node);
		}
		
		public override void OnStart (StartState state)
		{
			ConfigNode config = null;
			if(modded)
				config = configs.Find (c => c.GetValue ("name").Equals (configuration));
			
			if (config != null) {
				ModuleEngines thruster = (ModuleEngines) part.Modules["ModuleEngines"];
				ConfigNode newConfig = new ConfigNode ("MODULE");
				config.CopyTo (newConfig);
				newConfig.name = "MODULE";
				newConfig.SetValue ("name", "ModuleEngines");
				#if DEBUG
				print ("replacing ModuleEngines with:");
				print (newConfig.ToString ());
				#endif
				thruster.Load (newConfig);
			}
		}
		
		private void engineManagerGUI(int WindowID)
		{
			foreach (ConfigNode node in configs) {
				GUILayout.BeginHorizontal();
				if(node.GetValue ("name").Equals (configuration)) {
					GUILayout.Label ("Current configuration: " + configuration);
				} else if(GUILayout.Button ("Configure to " + node.GetValue ("name"))) {
					configuration = node.GetValue ("name");
					modded = true;
					config = new ConfigNode("MODULE");
					node.CopyTo (config);
					config.name = "MODULE";
					config.SetValue ("name", "ModuleEngines");
					#if DEBUG
					print ("replacing ModuleEngines with:");
					print (engine.config.ToString ());
					#endif
					part.Modules["ModuleEngines"].Load (config);
					UpdateSymmetryCounterparts();
				}
				GUILayout.EndHorizontal ();
			}
			GUILayout.BeginHorizontal();
			GUILayout.Label (part.Modules ["ModuleEngines"].GetInfo ());
			GUILayout.EndHorizontal ();
		}
		
		public int UpdateSymmetryCounterparts()
		{
			int i = 0;
			foreach (Part sPart in part.symmetryCounterparts) {
				ModuleEngineConfigs engine = (ModuleEngineConfigs)sPart.Modules ["ModuleEngineConfigs"];
				if (engine) {
					i++;
					engine.configuration = configuration;
					engine.config = config;
					engine.modded = true;
					ModuleEngines thruster = (ModuleEngines)sPart.Modules ["ModuleEngines"];
					thruster.Load (engine.config);
				}
			}
			return i;
		}
	}
}

