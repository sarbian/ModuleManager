using System.Collections.Generic;
using UnityEngine;
using KSP;

namespace ModularFuelTanks
{

	public class ModuleASASController: PartModule
	{

		public class ASASMode: IConfigNode
		{
			public ASASMode(ConfigNode node) {
				this.Load (node);
			}

			public ASASMode(string name, float Ki, float Kp, float Kd) {
				this.name = name;
				this.Ki = Ki;
				this.Kp = Kp;
				this.Kd = Kd;
			}

			public string name;
			public float Ki;
			public float Kp;
			public float Kd;

			public void Load(ConfigNode node)
			{
				if (node.HasValue ("name"))
					name = node.GetValue ("name");
				else
					name = "Default";
				if (node.HasValue ("Ki"))
					float.TryParse (node.GetValue ("Ki"), out Ki);
				if (node.HasValue ("Kp"))
					float.TryParse (node.GetValue ("Kp"), out Kp);
				if (node.HasValue ("Kd"))
					float.TryParse (node.GetValue ("Kd"), out Kd);
			}

			public void Save(ConfigNode node)
			{
				ConfigNode newNode = node.AddNode ("MODE");
				newNode.AddValue("name", name);
				newNode.AddValue ("Ki", Ki);
				newNode.AddValue ("Kp", Kp);
				newNode.AddValue ("Kd", Kd);
			}

		}


		public List<ASASMode> modes;

		[KSPField(isPersistant = true)]
		public int mode;

		UIPartActionWindow _myWindow = null; 
		UIPartActionWindow myWindow {
			get {
				if(_myWindow == null) {
					foreach(UIPartActionWindow window in FindObjectsOfType (typeof(UIPartActionWindow))) {
						if(window.part == part) _myWindow = window;
					}
				}
				return _myWindow;
			}
		}

		public override void OnSave (ConfigNode node)
		{
			base.OnSave (node);
			if(modes != null) // how does this even happen?
				foreach (ASASMode mode in modes)
					mode.Save (node);
		}

		public override void OnLoad (ConfigNode node)
		{
			print ("ModuleASASController.OnLoad");
			base.OnLoad (node);
			if (modes == null)
				modes = new List<ASASMode> ();
			else
				modes.Clear ();

			foreach (ConfigNode n in node.GetNodes ("MODE")) {
				modes.Add (new ASASMode(n));
			}
			print ("Loaded " + modes.Count + " nodes");
			RefreshActions ();
			print ("Actions refreshed");
			SetMode (0);
			print ("ModuleASASController loaded");
		}

		public override void OnStart (StartState state)
		{
			print ("ModuleASASController.OnStart");
			if (modes == null) {
				print ("modes is null");
				modes = new List<ASASMode> ();
				ModuleASASController prefab = null;
				if(part != null && part.partInfo != null && part.partInfo.partPrefab != null 
				   && part.partInfo.partPrefab.Modules != null) // I take no chances.
					prefab = (ModuleASASController) part.partInfo.partPrefab.Modules["ModuleASASController"];

				if(prefab != null) {
					print ("found prefab");

					foreach(ASASMode m in prefab.modes)
						modes.Add (new ASASMode(m.name, m.Ki, m.Kp, m.Kd));
				}
			}
			print ("Loaded " + modes.Count + " nodes");
			RefreshActions ();
			print ("Actions refreshed");
			SetMode (mode);
			print ("ModuleASASController started");
		}

		[KSPEvent(guiActive=true, guiName="Switch Mode")]
		public void SwitchMode()
		{
			NextMode ();
		}

		[KSPAction("Switch Mode")]
		public void SwitchAction(KSPActionParam param)
		{
			NextMode ();
		}

		[KSPAction("Mode 1")]
		public void SetMode1(KSPActionParam param)
		{
			SetMode (0);
		}

		[KSPAction("Mode 2")]
		public void SetMode2(KSPActionParam param)
		{
			SetMode (1);
		}

		[KSPAction("Mode 3")]
		public void SetMode3(KSPActionParam param)
		{
			SetMode (2);
		}

		public void NextMode()
		{
			SetMode (mode + 1);
		}

		public void SetMode(int newMode)
		{
			if (!(part is AdvSASModule))
				return;
			AdvSASModule asas = (AdvSASModule) part;
			if (modes.Count == 0) {
				modes.Add (new ASASMode("Default", asas.Ki, asas.Kp, asas.Kd));
			}
			if (newMode < 0 || newMode >= modes.Count)
				mode = 0;
			else
				mode = newMode;

			asas.Ki = modes[mode].Ki;
			asas.Kp = modes[mode].Kp;
			asas.Kd = modes[mode].Kd;

			Events ["SwitchMode"].guiName = "Mode: " + modes[mode].name;
			if(myWindow)
				myWindow.displayDirty = true;
		}

		public void OnGUI()
		{
			if (!(part is AdvSASModule))
				return;
			EditorLogic editor = EditorLogic.fetch;
			if (!HighLogic.LoadedSceneIsEditor || !editor || editor.editorScreen != EditorLogic.EditorScreen.Actions) {
				return;
			}
			
			if (EditorActionGroups.Instance.GetSelectedParts ().Contains (part)) {
				Rect screenRect = new Rect(0, 365, 430, (Screen.height - 365));
				GUILayout.Window (part.name.GetHashCode (), screenRect, ASASManagerGUI, "Configure " + part.partInfo.title);
			}

		}

		private void RefreshActions()
		{
			EditorLogic editor = EditorLogic.fetch;
			if (!(editor && part is AdvSASModule))
				return;

			AdvSASModule asas = (AdvSASModule)part;
			if (modes.Count == 0) {
				modes.Add (new ASASMode("Default", asas.Ki, asas.Kp, asas.Kd));
			}

			if (modes.Count < 2) {
				Actions[0].active = false;
				Actions[1].active = false;
				Actions[2].active = false;
				Actions[3].active = false;
			} else {
				Actions[0].active = true;
				Actions[1].active = true;
				Actions[1].guiName = modes[0].name;
				Actions[2].active = true;
				Actions[2].guiName = modes[1].name;
				if(modes.Count == 3) {
					Actions[3].active = true;
					Actions[3].guiName = modes[2].name;
				} else
					Actions[3].active = false;

			}

			if (editor.editorScreen == EditorLogic.EditorScreen.Actions 
			    && EditorActionGroups.Instance.GetSelectedParts().Contains (part)) {
				EditorActionPartSelector selector = new EditorActionPartSelector();
				selector.part = part;
				EditorActionGroups.Instance.ResetPart (selector);
			}
		}

		private void ASASManagerGUI(int WindowID)
		{
			if (!(part is AdvSASModule))
				return;
			ASASMode deleteMode = null;
			foreach (ASASMode mode in modes) {
				GUILayout.BeginHorizontal ();
				string newName = GUILayout.TextField (mode.name, GUILayout.Width (140));
				if(!newName.Equals(mode.name)) {
					mode.name = newName;
					RefreshActions ();
				}
				if(modes.Count > 1) {
					if (GUILayout.Button ("Delete"))
						deleteMode = mode;
				}
				GUILayout.EndHorizontal ();

				GUILayout.BeginHorizontal ();
				if (mode.Ki == 0) {
					if (GUILayout.Button ("Avionics mode (free heading)", GUILayout.Width (200))) {
						mode.Ki = 1.0f;
						mode.Kp = 0.6f;
						mode.Kd = 1.0f;
					}
				} else if (mode.Ki == 1) {
					if (GUILayout.Button ("ASAS mode (locked heading)", GUILayout.Width (200)))
						mode.Ki = 0.5f;
				} else {
					if (GUILayout.Button ("Custom mode (Ki = ", GUILayout.Width (140))) {
						mode.Ki = 0.0f;
						mode.Kp = 0.2f;
						mode.Kd = 0.2f;
					} else {
						float newKi;
						if (float.TryParse (GUILayout.TextField (mode.Ki.ToString ("F3"), GUILayout.Width (45)), out newKi))
							mode.Ki = newKi;
					}
					GUILayout.Label (")", GUILayout.Width (10));
				}
				GUILayout.EndHorizontal ();

				GUILayout.BeginHorizontal ();
				GUILayout.Label ("Responsiveness (Kp):", GUILayout.Width (140));
				float newKp;
				if (float.TryParse (GUILayout.TextField (mode.Kp.ToString ("F3"), GUILayout.Width (45)), out newKp))
					mode.Kp = newKp;
				
				GUILayout.EndHorizontal ();
				GUILayout.BeginHorizontal ();
				
				GUILayout.Label ("Control Buffer (Kd):", GUILayout.Width (140));
				float newKd;
				if (float.TryParse (GUILayout.TextField (mode.Kd.ToString ("F3"), GUILayout.Width (45)), out newKd))
					mode.Kd = newKd;
				GUILayout.EndHorizontal ();

			}
			if (deleteMode != null) {
				modes.Remove (deleteMode);
				RefreshActions();
			}

			if(modes.Count < 3) {
				if(GUILayout.Button ("Add New Mode")) {
					modes.Add (new ASASMode("Mode " + (modes.Count+1), 1, 0.6f, 1));
					RefreshActions();

				}
			}
		}
	}
}

