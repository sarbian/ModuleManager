using System.Collections.Generic;
using System.Reflection;
using System.Linq;
using UnityEngine;
using KSP;

namespace ModularFuelTanks
{

	public class ModuleHybridEngines : PartModule
	{ // originally developed from HybridEngineController from careo / ExsurgentEngineering.

		[KSPField(isPersistant=false)]
		public ConfigNode
			primaryEngine;
		
		[KSPField(isPersistant=false)]
		public ConfigNode
			secondaryEngine;
		
		[KSPField(isPersistant=false)]
		public string
			primaryModeName = "Primary";
		
		[KSPField(isPersistant=false)]
		public string
			secondaryModeName = "Secondary";
		
		[KSPField(guiActive=true, isPersistant=true, guiName="Current Mode")]
		public string
			currentMode;
		
		[KSPAction("Switch Engine Mode")]
		public void SwitchAction (KSPActionParam param)
		{
			SwitchEngine ();
		}
		
		public override void OnLoad (ConfigNode node)
		{
			
			if (node.HasNode ("primaryEngine")) {
				primaryEngine = node.GetNode ("primaryEngine");
				secondaryEngine = node.GetNode ("secondaryEngine");
			} else {
				var prefab = (ModuleHybridEngines)part.partInfo.partPrefab.Modules ["ModuleHybridEngines"];
				primaryEngine = prefab.primaryEngine;
				secondaryEngine = prefab.secondaryEngine;
			}
			if (currentMode == null) {
				currentMode = primaryModeName;
			}
			if (ActiveEngine == null) {
				if (currentMode == primaryModeName)
					AddEngine (primaryEngine);
				else
					AddEngine (secondaryEngine);
			}
		}
		
		public override void OnStart (StartState state)
		{
			base.OnStart (state);
			if (state == StartState.Editor)
				return;
			SwitchEngine();
			SwitchEngine();
			
			
		}
		
		public void SetEngine(ConfigNode config)
		{
			bool engineActive = ActiveEngine.getIgnitionState;
			ActiveEngine.EngineIgnited = false;
			
			//  remove all fuel gauges
			ClearMeters (); 
			propellants.Clear ();

			//  clear the old engine state
			ActiveEngine.atmosphereCurve = new FloatCurve();
			ActiveEngine.velocityCurve = new FloatCurve ();

			//  load the new engine state
			ActiveEngine.Load (config);

			if (config.HasValue ("useVelocityCurve") && (config.GetValue ("useVelocityCurve").ToLowerInvariant () == "true")) {
				ActiveEngine.velocityCurve.Load (config.GetNode ("velocityCurve"));
			} else {
				ActiveEngine.useVelocityCurve = false;
			}

			//  set up propellants
			foreach (ModuleEngines.Propellant propellant in ActiveEngine.propellants) {
				if(propellant.drawStackGauge) { // we need to handle fuel gauges ourselves
					propellant.drawStackGauge = false;
					propellants.Add (propellant);
				}
			}
			ActiveEngine.SetupPropellant ();
			
			if (engineActive)
				ActiveEngine.Actions ["ActivateAction"].Invoke (new KSPActionParam (KSPActionGroup.None, KSPActionType.Activate));
		}
		bool AddEngine (ConfigNode config)
		{
			part.AddModule ("ModuleEngines");
			if (!ActiveEngine)
				return false;
			SetEngine (config);
			return true;
		}
		
		public ModuleEngines ActiveEngine {
			get { return (ModuleEngines)part.Modules ["ModuleEngines"]; }
			
		}
		
		[KSPEvent(guiActive=true, guiName="Switch Engine Mode")]
		public void SwitchEngine ()
		{
			if (currentMode == primaryModeName) {
				currentMode = secondaryModeName;
				SetEngine(secondaryEngine);
			} else {
				currentMode = primaryModeName;
				SetEngine(primaryEngine);
			}        
		}
		
		public void FixedUpdate ()
		{
			if (ActiveEngine.getIgnitionState) { // engine is active, render fuel gauges
				foreach (ModuleEngines.Propellant propellant in propellants) {
					if (!meters.ContainsKey (propellant.name)) // how did we miss one?
						meters.Add (propellant.name, NewMeter (propellant.name));
					
					double amount = 0d;
					double maxAmount = 0d;
					
					List<PartResource> sources = new List<PartResource> ();
					part.GetConnectedResources (propellant.id, sources);
					
					foreach (PartResource source in sources) {
						amount += source.amount;
						maxAmount += source.maxAmount;
					}
					
					if (propellant.name.Equals ("IntakeAir")) {
						double minimum = (from modules in vessel.Parts 
						                  from module in modules.Modules.OfType<ModuleEngines> () 
						                  from p in module.propellants 
						                  where p.name == "IntakeAir"
						                  select module.ignitionThreshold * p.currentRequirement).Sum ();
						
						// linear scale
						meters ["IntakeAir"].SetValue ((float)((amount - minimum) / (maxAmount - minimum)));
					} else {
						meters [propellant.name].SetValue ((float)(amount / maxAmount));
					}
				}
			} else if(meters.Count > 0) { // engine is shut down, remove all fuel gauges
				ClearMeters();
			}
		}
		
		
		List<ModuleEngines.Propellant> _props; 
		List<ModuleEngines.Propellant> propellants 
		{
			get {
				if(_props == null)
					_props = new List<ModuleEngines.Propellant>();
				return _props;
			}
		}
		private Dictionary<string, VInfoBox> _meters;
		public Dictionary<string, VInfoBox> meters
		{
			get {
				if(_meters == null)
					_meters = new Dictionary<string, VInfoBox>();
				return _meters;
			}
		}
		
		public void ClearMeters() {
			foreach(VInfoBox meter in meters.Values) {
				part.stackIcon.RemoveInfo (meter);	
			}
			meters.Clear ();
		}
		
		VInfoBox NewMeter (string resourceName)
		{
			VInfoBox meter = part.stackIcon.DisplayInfo ();
			if (resourceName == "IntakeAir") {
				meter.SetMessage ("Air");
				meter.SetProgressBarColor (XKCDColors.White);
				meter.SetProgressBarBgColor (XKCDColors.Grey);
			} else {
				meter.SetMessage (resourceName);
				meter.SetMsgBgColor (XKCDColors.DarkLime);
				meter.SetMsgTextColor (XKCDColors.ElectricLime);
				meter.SetProgressBarColor (XKCDColors.Yellow);
				meter.SetProgressBarBgColor (XKCDColors.DarkLime);
			}
			meter.SetLength (2f);
			meter.SetValue (0f);
			
			return meter;
		}
		
	}

	public class ModuleEngineConfigs : PartModule
	{
		[KSPField(isPersistant = true)] 
		public string configuration = "";

		[KSPField(isPersistant = true)] 
		public string type = "ModuleEngines";

		[KSPField(isPersistant = true)] 
		public string thrustRating = "maxThrust";

		[KSPField(isPersistant = true)] 
		public bool modded = false;
		
		public List<ConfigNode> configs;
		public ConfigNode config;
		
		public override void OnAwake ()
		{
			if(configs == null)
				configs = new List<ConfigNode>();
		}
		
		public override string GetInfo ()
		{
			string info = "\nAlternate configurations:\n";
			foreach (ConfigNode config in configs) {
				if(!config.GetValue ("name").Equals (configuration)) {
					info += "   " + config.GetValue ("name") + "\n";
					if(config.HasValue (thrustRating))
						info += "    (" + config.GetValue (thrustRating) + " Thrust";
					else
						info += "    (Unknown Thrust";
					
					FloatCurve isp = new FloatCurve();
					if(config.HasNode ("atmosphereCurve")) {
						isp.Load (config.GetNode ("atmosphereCurve"));
						info  += ", "
							+ isp.Evaluate (isp.maxTime).ToString() + "-" 
						  	+ isp.Evaluate (isp.minTime).ToString() + "Isp";
					}
					info += ")\n";
				}
				
				
			}
			return info;
		}
		
		public void OnGUI()
		{
			EditorLogic editor = EditorLogic.fetch;
			if (!HighLogic.LoadedSceneIsEditor || !editor || editor.editorScreen != EditorLogic.EditorScreen.Actions) {
				return;
			}
			
			if (EditorActionGroups.Instance.GetSelectedParts ().Contains (part)) {
				Rect screenRect = new Rect(0, 365, 430, (Screen.height - 365));
				GUILayout.Window (part.name.GetHashCode (), screenRect, engineManagerGUI, "Configure " + part.partInfo.title);
			}
		}
		
		public override void OnLoad (ConfigNode node)
		{
			base.OnLoad (node);
			if (configs == null)
				configs = new List<ConfigNode> ();
			else
				configs.Clear ();
			
			foreach (ConfigNode subNode in node.GetNodes ("CONFIG")) {
				ConfigNode newNode = new ConfigNode("CONFIG");
				subNode.CopyTo (newNode);
				configs.Add (newNode);
			}
		}
		
		public override void OnSave (ConfigNode node)
		{
		}

		public void SetConfiguration(string newConfiguration)
		{
			ConfigNode newConfig = configs.Find (c => c.GetValue ("name").Equals (newConfiguration));			
			if (newConfig != null) {
				configuration = newConfiguration;
				config = new ConfigNode ("MODULE");
				newConfig.CopyTo (config);
				config.name = "MODULE";
				config.SetValue ("name", type);
				#if DEBUG
				print ("replacing " + type + " with:");
				print (newConfig.ToString ());
				#endif

				// clear all FloatCurves
				foreach(FieldInfo field in part.Modules[type].GetType().GetFields()) { 
					if(field.FieldType == typeof(FloatCurve))
						field.SetValue (part.Modules[type], new FloatCurve());
				}
				part.Modules[type].Load (config);
				part.Modules[type].OnStart (StartState.None);
			}
		}

		public override void OnStart (StartState state)
		{
			if(configs.Count == 0 && part.partInfo != null 
			   && part.partInfo.partPrefab.Modules.Contains ("ModuleEngineConfigs")) {
				ModuleEngineConfigs prefab = (ModuleEngineConfigs) part.partInfo.partPrefab.Modules["ModuleEngineConfigs"];
				configs = prefab.configs;
			}
			SetConfiguration (configuration);

		}
		
		private void engineManagerGUI(int WindowID)
		{
			foreach (ConfigNode node in configs) {
				GUILayout.BeginHorizontal();
				if(node.GetValue ("name").Equals (configuration))
					GUILayout.Label ("Current configuration: " + configuration);
				else if(GUILayout.Button ("Configure to " + node.GetValue ("name"))) {
					SetConfiguration(node.GetValue ("name"));
					UpdateSymmetryCounterparts();
				}
				GUILayout.EndHorizontal ();
			}
			GUILayout.BeginHorizontal();
			GUILayout.Label (part.Modules [type].GetInfo ());
			GUILayout.EndHorizontal ();
		}
		
		public int UpdateSymmetryCounterparts()
		{
			int i = 0;
			foreach (Part sPart in part.symmetryCounterparts) {
				ModuleEngineConfigs engine = (ModuleEngineConfigs)sPart.Modules ["ModuleEngineConfigs"];
				if (engine) {
					i++;
					engine.SetConfiguration (configuration);
				}
			}
			return i;
		}
	}
}

