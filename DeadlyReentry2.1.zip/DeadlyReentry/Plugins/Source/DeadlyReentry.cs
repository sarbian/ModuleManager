﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

using ModuleManager;

namespace DeadlyReentry
{
	public class ModuleAeroReentry: PartModule
	{
		static string FormatTime(double time)
		{
			int iTime = (int) time % 3600;
			int seconds = iTime % 60;
			int minutes = (iTime / 60) % 60;
			int hours = (iTime / 3600);
			return hours.ToString ("D2") 
				   + ":" + minutes.ToString ("D2") + ":" + seconds.ToString ("D2");
		}

		FXGroup _ablationSmokeFX = null;
		FXGroup ablationSmokeFX {
			get {
				if(_ablationSmokeFX == null) {
					_ablationSmokeFX = new FXGroup (part.partName + "_Smoking");
					_ablationSmokeFX.fxEmitters.Add (Emitter("fx_smokeTrail_medium"));
				}
				return _ablationSmokeFX;
			}
		}

		FXGroup _ablationFX = null;
		FXGroup ablationFX {
			get {
				if(_ablationFX == null) {
					_ablationFX = new FXGroup (part.partName + "_Burning");
					_ablationFX.fxEmitters.Add (Emitter("fx_exhaustFlame_yellow"));
					_ablationFX.fxEmitters.Add (Emitter("fx_exhaustSparks_yellow"));

				}
				return _ablationFX;
			}
		}

		[KSPField(isPersistant = false, guiActive = false, guiName = "Shockwave", guiUnits = "",   guiFormat = "G")]
		public string displayShockwave;

		[KSPField(isPersistant = false, guiActive = true, guiName = "Temperature", guiUnits = "C",   guiFormat = "F0")]
		public float displayTemperature;

		[KSPField(isPersistant = false, guiActive = false, guiName = "Acceleration", guiUnits = "G",   guiFormat = "F3")]
		public float displayGForce;

		[KSPField(isPersistant = false, guiActive = true, guiName = "Damage", guiUnits = "",   guiFormat = "G")]
		public string displayDamage;

		[KSPField(isPersistant = true)]
		public float adjustCollider = 0;

		[KSPField(isPersistant = true)]
		public float crashTolerance = 8;

		[KSPField(isPersistant = true)]
		public float damage = 0;

		[KSPField(isPersistant = true)]
		public bool dead = false;

		private double lastGForce = 0;

		/*
		[KSPEvent (guiName = "Inspect Damage", guiActiveUnfocused = true, externalToEVAOnly = true, guiActive = false, unfocusedRange = 10f)]
		public void InspectDamage()
		{
			Events ["InspectDamage"].guiName = "Attempt Repairs (" + displayDamage + ")";
		}*/

		public virtual float AdjustedHeat(Vector3 velocity, float shockwave, float temp)
		{
			return temp;
		}

		public bool IsShielded(Vector3 direction)
		{
			if (part.Modules.Contains ("ModuleParachute")) {
				ModuleParachute p = (ModuleParachute) part.Modules["ModuleParachute"];
				if(p.deploymentState != ModuleParachute.deploymentStates.STOWED && p.deploymentState != ModuleParachute.deploymentStates.CUT)
					return false;
			}
			Ray ray;
			ray.direction = direction.normalized;
			ray.origin = part.transform.position + ray.direction * adjustCollider;
			RaycastHit[] hits = Physics.RaycastAll (ray, 10);
			foreach (RaycastHit hit in hits) {
				if(hit.rigidbody != null && hit.collider != part.collider) {
					return true;
				}
			}
			return false;
		}


		public float ReentryHeat(Vector3 velocity) 
		{
			if (part == null || vessel == null || part.Rigidbody == null || vessel.flightIntegrator == null)
				return 0;
			float shockwave = velocity.magnitude - 275;
			float ambient = vessel.flightIntegrator.getExternalTemperature ();
			if (shockwave < ambient) {
				shockwave = ambient;
				displayShockwave = shockwave.ToString ("F0") + "C (Ambient)";
			} else if (vessel.atmDensity == 0) {
				shockwave = 0;
				displayShockwave = "None (vacuum)";
			} else {
				if (IsShielded(velocity))
					displayShockwave = "Shielded";
				else {
					displayShockwave = shockwave.ToString ("F0") + "C";
					return AdjustedHeat (velocity, shockwave, 
		                                ReentryPhysics.TemperatureDelta (vessel.atmDensity, shockwave, part.temperature));
				}
			}
			return 0;
		}


		public void FixedUpdate ()
		{
			if (dead || part.physicalSignificance == Part.PhysicalSignificance.NONE || !FlightGlobals.ready)
				return;

			Fields ["displayShockwave"].guiActive = ReentryPhysics.debugging;
			Fields ["displayGForce"].guiActive = ReentryPhysics.debugging;
			if(damage > 0.5)
				displayDamage = "Critical";
			else if(damage > 0.25)
				displayDamage = "Severe";
			else if(damage > 0.125)
				displayDamage = "Moderate";
			else if(damage > 0)
				displayDamage = "Light";
			else
				displayDamage = "None";

			Vector3 velocity = (part.Rigidbody.GetPointVelocity(part.transform.position) + Krakensbane.GetFrameVelocityV3f() - Krakensbane.GetLastCorrection() * TimeWarp.fixedDeltaTime);
			part.temperature += ReentryHeat (velocity);
			displayTemperature = part.temperature;
			CheckForFire (velocity);
			CheckGeeForces ();


		}

		public void AddDamage(float dmg)
		{
			if (dead || part == null || part.partInfo == null || part.partInfo.partPrefab == null)
				return;
			if(ReentryPhysics.debugging)
				print (part.partInfo.title + ": +" + dmg + " damage");
			damage += dmg;
			part.maxTemp = part.partInfo.partPrefab.maxTemp * (1 - 0.15f * damage);
			part.breakingForce = part.partInfo.partPrefab.breakingForce * (1 - damage);
			part.breakingTorque = part.partInfo.partPrefab.breakingTorque * (1 - damage);
			part.crashTolerance = part.partInfo.partPrefab.crashTolerance * (1 - damage);
		}

		public void CheckGeeForces()
		{
			float deltaTime = TimeWarp.fixedDeltaTime;
			double geeForce = vessel.geeForce_immediate;
			if(ReentryPhysics.debugging) {
				print ("dead:" + dead);
				print ("part:" + part == null);
				print ("vessel:" + vessel == null);
				print ("deltaTime:" + deltaTime);
				print ("geeForce:" + geeForce.ToString ("F3"));
			}
			if (dead || part == null || vessel == null || deltaTime > 0.5 || deltaTime <= 0)
				return; // don't check G-forces in warp
			else if (geeForce > 40 && geeForce > lastGForce) {
				// G forces over 40 are probably a Kraken twitch unless they last multiple frames
				displayGForce = displayGForce * (1 - deltaTime) + (float)(lastGForce * deltaTime);
			} else {
				//keep a running average of G force over 1s, to further prevent absurd spikes (mostly decouplers & parachutes)
				displayGForce = displayGForce * (1 - deltaTime) + (float)(vessel.geeForce_immediate * deltaTime);
			}

			double gTolerance = Math.Pow (5 * part.crashTolerance, 0.5);
			if (displayGForce > gTolerance) { // G tolerance is based roughly on crashTolerance
				AddDamage (deltaTime * (float) (displayGForce / gTolerance - 1.0f));
			}

			if (damage >= 1.0f && !dead) {
				dead = true;
				FlightLogger.eventLog.Add ("[" + FormatTime(FlightGlobals.ActiveVessel.missionTime) + "] " 
				                           + part.partInfo.title + " exceeded g-force tolerance.");
				part.explode ();
			}
			lastGForce = vessel.geeForce_immediate;
		}

		public void CheckForFire(Vector3 velocity)
		{	
			float deltaTime = TimeWarp.fixedDeltaTime;
			if (dead || part == null | part.Modules == null)
				return;

			if (part.temperature > part.maxTemp * 0.85) {
				// Handle client-side fire stuff.
				// OH GOD IT'S ON FIRE.
				float tempRatio = part.temperature / part.maxTemp;
				AddDamage (deltaTime * 0.1f * tempRatio / part.mass);
				new GameEvents.ExplosionReaction (0, damage);
				
				if(part.Modules.Contains ("ModuleEngines") && damage < 1) 
					part.temperature = tempRatio * part.maxTemp;
				else if(damage < 1)// non-engines can keep burning
					part.temperature = (tempRatio * (1 - damage) + 0.9f * damage) * part.maxTemp;
				
				if (part.temperature > part.maxTemp || damage >= 1.0f) { // has it burnt up completely?
					foreach(GameObject fx in ablationFX.fxEmitters)
						GameObject.DestroyImmediate(fx);
					foreach(GameObject fx in ablationSmokeFX.fxEmitters)
						GameObject.DestroyImmediate(fx);
					if(!dead) {
						dead = true;
						FlightLogger.eventLog.Add ("[" + FormatTime(FlightGlobals.ActiveVessel.missionTime) + "] " 
						                           + part.partInfo.title + " burned up on reentry.");
						part.explode ();
					}
					return;
					
				} else {
					foreach(GameObject fx in ablationFX.fxEmitters) {
						fx.SetActive (true);
						fx.transform.LookAt (part.transform.position + velocity);
						fx.transform.Rotate (90, 0, 0);
					}
					foreach(GameObject fx in ablationSmokeFX.fxEmitters) {
						fx.SetActive (vessel.atmDensity > 0.5);
						fx.transform.LookAt (part.transform.position + velocity);
						fx.transform.Rotate (90, 0, 0);
					}
				}
			} else { // not on fire.
				foreach(GameObject fx in ablationFX.fxEmitters)
					fx.SetActive (false);
				foreach(GameObject fx in ablationSmokeFX.fxEmitters)
					fx.SetActive (false);
				
			}
		}
		public GameObject Emitter(string fxName) {
			GameObject fx = (GameObject)UnityEngine.Object.Instantiate (UnityEngine.Resources.Load ("Effects/" + fxName));

			fx.transform.parent = part.transform;
			fx.transform.localPosition = new Vector3 (0, 0, 0);
			fx.transform.localRotation = Quaternion.identity;
			fx.SetActive (false);
			return fx;

		}

	}

	public class ModuleHeatShield: ModuleAeroReentry
	{
		/*

	MODULE
	{
		name = ModuleHeatShield
		direction = 0, -1, 0 // bottom of pod
		reflective = 0.05 // 5% of heat is ignored at correct angle
		ablative = AblativeShielding
		loss
		{ // loss is based on the shockwave temperature
			key = 450 0 // start ablating at 450 degrees C
			key = 550 2 // peak ablation at 550 degrees C
			key = 3000 2.5 // max ablation at 3000 degrees C
		}
		dissipation
		{ // dissipation is based on the part's current temperature
				key = 300 0 // begin ablating at 300 degrees C
				key = 500 330 // maximum dissipation at 500 degrees C
		}
	}
	RESOURCE
	{
		name = AblativeShielding
		amount = 250
		maxAmount = 250
	}
	*/

		[KSPField(isPersistant = false, guiActive = false, guiName = "angle", guiUnits = " ", guiFormat = "F3")]
		public float dot;


		[KSPField(isPersistant = true)]
		public int deployAnimationController;

		[KSPField(isPersistant = true)]
		public Vector3 direction;

		[KSPField(isPersistant = true)]
		public float reflective;

		[KSPField(isPersistant = true)]
		public string ablative = "AblativeShielding";

		[KSPField(isPersistant = true)]
		public FloatCurve loss = new FloatCurve();

		[KSPField(isPersistant = true)]
		public FloatCurve dissipation = new FloatCurve();

		private bool canShield {
			get {
				if(!part.Modules.Contains ("ModuleAnimateGeneric"))
					return true;
				return deployAnimationController == ((ModuleAnimateGeneric) part.Modules["ModuleAnimateGeneric"]).animTime;
			}
		}

		public override string GetInfo()
		{
			string s = "Active Heat Shield";
			if (direction.x != 0 || direction.y != 0 || direction.z != 0)
				s += " (directional)";
			return s;
		}

		public override float AdjustedHeat(Vector3 velocity, float shockwave, float temp)
		{
			if(!canShield)// Shielded Clamp-O-Trons and other parts that have an 'open' and 'shielded' state
				dot = -1; 
			
			else if (direction.magnitude == 0) // an empty vector means the shielding exists on all sides
				dot = 1; 
			else // check the angle between the shock front and the shield
				dot = Vector3.Dot (velocity.normalized, part.transform.TransformDirection(direction).normalized);

			
			if (dot > 0 && temp > 0) {
				//radiate away some heat
				float rad = temp * dot * reflective;
				temp -= rad  * (1 - damage) * (1 - damage);
				if(loss.Evaluate(shockwave) > 0
				   && part.Resources.Contains (ablative)) {
					// ablate away some shielding
					float ablation = (float) (dot 
					                          * loss.Evaluate((float) Math.Pow (shockwave, ReentryPhysics.temperatureExponent)) 
					                          * Math.Pow (vessel.atmDensity, ReentryPhysics.densityExponent) 
					                          * TimeWarp.fixedDeltaTime);
				
					if(part.Resources[ablative].amount < ablation)
						ablation = (float) part.Resources[ablative].amount;
					// wick away some heat with the shielding
					part.Resources[ablative].amount -= ablation;
					temp -= dissipation.Evaluate(part.temperature) * ablation  * (1 - damage) * (1 - damage);
				}
			}
			return temp;
		}
	}


	[KSPAddon(KSPAddon.Startup.Flight, false)]
    public class ReentryPhysics : MonoBehaviour
    {
		private static AerodynamicsFX _afx;

        public static AerodynamicsFX afx {
			get {
				if (_afx == null) {
					GameObject fx = GameObject.Find ("FXLogic");
					if (fx != null) {
						_afx = fx.GetComponent<AerodynamicsFX> ();
					}
				}
				return _afx;
			}
		}

        public static float heatMultiplier = 20.0f;
		public static float temperatureExponent = 1.0f;
		public static float densityExponent = 1.0f;

		public static float startThermal = 800.0f;
		public static float fullThermal = 1150.0f;

        public static bool debugging = false;
        protected Rect windowPos = new Rect(100, 100, 0, 0);

		public static float TemperatureDelta(double density, float temp1, float temp2)
		{
			if (temp1 < temp2 || density == 0 || temp1 < 0)
				return 0;
			return (float) ( Math.Pow (Math.Abs(temp1 - temp2), temperatureExponent) 
						   * Math.Pow (density, densityExponent)
						   * heatMultiplier * TimeWarp.fixedDeltaTime);
		}

		public void Start()
		{
			foreach (ConfigNode node in GameDatabase.Instance.GetConfigNodes ("REENTRY_EFFECTS")) {
				if(node.HasValue("heatMultiplier"))
					float.TryParse (node.GetValue ("heatMultiplier"), out heatMultiplier);
				if(node.HasValue("startThermal"))
					float.TryParse (node.GetValue ("startThermal"), out startThermal);
				if(node.HasValue("fullThermal"))
					float.TryParse (node.GetValue ("fullThermal"), out fullThermal);
				if(node.HasValue("temperatureExponent"))
					float.TryParse (node.GetValue ("temperatureExponent"), out temperatureExponent);
				if(node.HasValue("densityExponent"))
					float.TryParse (node.GetValue ("densityExponent"), out densityExponent);
				if(node.HasValue("debugging"))
					bool.TryParse (node.GetValue ("debugging"), out debugging);
				break;
			};
		}

        public void OnGUI()
        {
            if (debugging)
            {
                windowPos = GUILayout.Window("DeadlyReentry".GetHashCode(), windowPos, DrawWindow, "Deadly Reentry 2.0 Setup");
            }
        }

		private void FixAeroFX(AerodynamicsFX aeroFX)
		{
			if (afx.velocity.magnitude < startThermal) // approximate speed where shockwaves begin visibly glowing
				afx.state = 0;
			else if (afx.velocity.magnitude >= fullThermal)
				afx.state = 1;
			else
				afx.state = (afx.velocity.magnitude - startThermal) / (fullThermal - startThermal);
		}

		public void FixedUpdate()
		{
			FixAeroFX (afx);
		}

		public void LateUpdate()
		{
			FixAeroFX (afx);
		}


        public void Update()
        {
            if (Input.GetKeyDown(KeyCode.R) && Input.GetKey(KeyCode.LeftAlt) && Input.GetKey(KeyCode.D))
            {
                debugging = !debugging;
            }

            if (FlightGlobals.ready)
            {
                if ((afx != null))
                {
					FixAeroFX(afx);
				
					foreach (Vessel vessel in FlightGlobals.Vessels) 
					{
						if(vessel.loaded)// && afx.FxScalar > 0)
						{
		                    foreach (Part p in vessel.Parts)
		                    {
								if(!(p.Modules.Contains ("ModuleAeroReentry") || p.Modules.Contains ("ModuleHeatShield")))
									ModuleManager.ModuleManager.Awaken (p.AddModule ("ModuleAeroReentry"));

							}
                        }
                    }
                }
            }
        }

        public void DrawWindow(int windowID)
        {
            GUIStyle buttonStyle = new GUIStyle(GUI.skin.button);
            buttonStyle.padding = new RectOffset(5, 5, 3, 0);
            buttonStyle.margin = new RectOffset(1, 1, 1, 1);
            buttonStyle.stretchWidth = false;
            buttonStyle.stretchHeight = false;

            GUIStyle labelStyle = new GUIStyle(GUI.skin.label);
            labelStyle.wordWrap = false;

            GUILayout.BeginVertical();

            GUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            if (GUILayout.Button("X", buttonStyle))
            {
                debugging = false;
            }
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("Temperature Exponent:", labelStyle);
            string newTemperatureExponent = GUILayout.TextField(temperatureExponent.ToString(), GUILayout.MinWidth(100));
            GUILayout.EndHorizontal();

			GUILayout.BeginHorizontal();
			GUILayout.Label("Density Exponent:", labelStyle);
			string newDensityExponent = GUILayout.TextField(densityExponent.ToString(), GUILayout.MinWidth(100));
			GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("Multiplier:", labelStyle);
            string newMultiplier = GUILayout.TextField(heatMultiplier.ToString(), GUILayout.MinWidth(100));
            GUILayout.EndHorizontal();

			GUILayout.BeginHorizontal();
			GUILayout.Label("F/X Transition", labelStyle);
			GUILayout.EndHorizontal();

			GUILayout.BeginHorizontal();
			GUILayout.Label("Begin at:", labelStyle);
			string newThermal = GUILayout.TextField(startThermal.ToString(), GUILayout.MinWidth(100));
			GUILayout.Label("m/s", labelStyle);
			GUILayout.EndHorizontal();

			GUILayout.BeginHorizontal();
			GUILayout.Label("Full at:", labelStyle);
			string newThermalFull = GUILayout.TextField(fullThermal.ToString(), GUILayout.MinWidth(100));
			GUILayout.Label("m/s", labelStyle);
			GUILayout.EndHorizontal();

			GUILayout.BeginHorizontal();
			if (GUILayout.Button ("Save")) {
				ConfigNode node = new ConfigNode("@REENTRY_EFFECTS[Default]:Final");
				ConfigNode savenode = new ConfigNode();
				node.AddValue ("@heatMultiplier", heatMultiplier.ToString ());
				node.AddValue ("@startThermal", startThermal.ToString ());
				node.AddValue ("@fullThermal", fullThermal.ToString ());
				node.AddValue ("@temperatureExponent", temperatureExponent.ToString ());
				node.AddValue ("@densityExponent", densityExponent.ToString ());
				savenode.AddNode (node);
				savenode.Save (KSPUtil.ApplicationRootPath.Replace ("\\", "/") + "GameData/DeadlyReentry/custom.cfg");
			}
			GUILayout.EndHorizontal();

            GUILayout.EndVertical();

            GUI.DragWindow();

            if (GUI.changed)
            {
                float newValue;
                if (float.TryParse(newTemperatureExponent, out newValue))
                {
                    temperatureExponent = newValue;
                }

				if (float.TryParse(newDensityExponent, out newValue))
				{
					densityExponent = newValue;
				}

                if (float.TryParse(newMultiplier, out newValue))
                {
                    heatMultiplier = newValue;
                }
				if (float.TryParse(newThermal, out newValue))
				{
					startThermal = newValue;
				}
				if (float.TryParse(newThermalFull, out newValue))
				{
					fullThermal = newValue;
				}
			}
        }
    }
}
