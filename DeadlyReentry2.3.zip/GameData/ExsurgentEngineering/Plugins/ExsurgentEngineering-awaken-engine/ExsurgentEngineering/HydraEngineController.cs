using System;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

// TODO: render stack icons. some based regular fuel levels, others like 
//    intake air do as % of max
using System.Reflection;

public class HydraEngineController : PartModule
{
	[KSPField(isPersistant=false)]
	public ConfigNode
		primaryEngine;

	[KSPField(isPersistant=false)]
	public ConfigNode
		secondaryEngine;

	[KSPField(isPersistant=false)]
	public string
		primaryModeName = "Primary";

	[KSPField(isPersistant=false)]
	public string
		secondaryModeName = "Secondary";

	[KSPField(guiActive=true, isPersistant=true, guiName="Current Mode")]
	public string
		currentMode;

	[KSPAction("Switch Engine Mode")]
	public void SwitchAction (KSPActionParam param)
	{
		SwitchEngine ();
	}

	public override void OnLoad (ConfigNode node)
	{
   
		if (node.HasNode ("primaryEngine")) {
			primaryEngine = node.GetNode ("primaryEngine");
			secondaryEngine = node.GetNode ("secondaryEngine");
		} else {
			var prefab = (HydraEngineController)part.partInfo.partPrefab.Modules ["HydraEngineController"];
			primaryEngine = prefab.primaryEngine;
			secondaryEngine = prefab.secondaryEngine;
		}
		if (currentMode == null) {
			currentMode = primaryModeName;
		}
		if (ActiveEngine == null) {
			if (currentMode == primaryModeName)
				AddEngine (primaryEngine);
			else
				AddEngine (secondaryEngine);
		}
	}

	public override void OnStart (StartState state)
	{
		base.OnStart (state);
		if (state == StartState.Editor)
			return;
		SwitchEngine();
		SwitchEngine();


	}
	bool Awaken(PartModule module)
	{
		// borrowed from https://github.com/Ialdabaoth/ModuleManager/blob/master/moduleManager.cs
		MethodInfo awakeMethod = typeof(PartModule).GetMethod ("Awake", BindingFlags.Instance | BindingFlags.NonPublic);
		if (awakeMethod == null)
			return false;
		object[] paramList = new object[] { };
		awakeMethod.Invoke(module, paramList);
		return true;
	}

	bool AddEngine (ConfigNode engineConfig)
	{
		ModuleEngines module = (ModuleEngines) part.AddModule ("ModuleEngines");
		if (!module || !Awaken (module))
			return false;
		module.Load (engineConfig);
		propellants.Clear ();
		foreach (ModuleEngines.Propellant prop in module.propellants) {
			if(prop.drawStackGauge) { // we need to handle fuel gauges ourselves
				prop.drawStackGauge = false;
				propellants.Add (prop);
			}
		}
		return true;
	}

	public ModuleEngines ActiveEngine {
		get { return (ModuleEngines)part.Modules ["ModuleEngines"]; }

	}

	[KSPEvent(guiActive=true, guiName="Switch Engine Mode")]
	public void SwitchEngine ()
	{
		ConfigNode nextEngine;
		if (currentMode == primaryModeName) {
			currentMode = secondaryModeName;
			nextEngine = secondaryEngine;
		} else {
			currentMode = primaryModeName;
			nextEngine = primaryEngine;
		}

		// swap data

		engineActive = ActiveEngine.getIgnitionState;
		ActiveEngine.EngineIgnited = false;

		if (meters == null)
			print ("meters is null");


		ActiveEngine.propellants.Clear ();
		ActiveEngine.velocityCurve = new FloatCurve ();
		ActiveEngine.atmosphereCurve = new FloatCurve ();

		ActiveEngine.Fields.Load (nextEngine);

		if (nextEngine.HasValue ("useVelocityCurve") && (nextEngine.GetValue ("useVelocityCurve").ToLowerInvariant () == "true")) {
			ActiveEngine.velocityCurve.Load (nextEngine.GetNode ("velocityCurve"));
		} else {
			ActiveEngine.useVelocityCurve = false;
		}


		if (part.stackIcon == null)
			print ("stackIcon is null");
		propellants.Clear ();
		foreach (ConfigNode n in nextEngine.nodes) {
			if (n.name == "PROPELLANT") {
				ModuleEngines.Propellant prop = new ModuleEngines.Propellant ();
				prop.Load (n);
				if(prop.drawStackGauge) {
					prop.drawStackGauge = false;
					propellants.Add (prop);
				}
				ActiveEngine.propellants.Add (prop);
			}
		}


		ActiveEngine.SetupPropellant ();

		if (engineActive) {
			ActiveEngine.Actions ["ActivateAction"].Invoke (new KSPActionParam (KSPActionGroup.None, KSPActionType.Activate));
			InitializeMeters();
		}
        
	}

	public void FixedUpdate ()
	{
		if (engineActive != ActiveEngine.getIgnitionState) {
			engineActive = ActiveEngine.getIgnitionState;
			InitializeMeters();
		}
		foreach(ModuleEngines.Propellant propellant in propellants) {
			double amount = 0d;
			double maxAmount = 0d;
		
			List<PartResource> sources = new List<PartResource> ();
			part.GetConnectedResources (propellant.id, sources);
				
			foreach (PartResource source in sources) {
				amount += source.amount;
				maxAmount += source.maxAmount;
			}

			if(propellant.name.Equals("IntakeAir")) {
				double minimum = (from modules in vessel.Parts 
				              	  from module in modules.Modules.OfType<ModuleEngines> () 
				              	  from p in module.propellants 
				              	  where p.name == "IntakeAir"
				              	  select module.ignitionThreshold * p.currentRequirement).Sum ();
				
					// linear scale
				meters["IntakeAir"].SetValue((float) ((amount - minimum) / (maxAmount - minimum)));
			} else {
				meters[propellant.name].SetValue ((float) (amount / maxAmount));
			}
		}

	}


	public bool engineActive = false;
	List<ModuleEngines.Propellant> _props; 
	List<ModuleEngines.Propellant> propellants 
	{
		get {
			if(_props == null)
				_props = new List<ModuleEngines.Propellant>();
			return _props;
		}
	}
	private Dictionary<string, VInfoBox> _meters;
	public Dictionary<string, VInfoBox> meters
	{
		get {
			if(_meters == null)
				_meters = new Dictionary<string, VInfoBox>();
			return _meters;
		}
	}

	public void InitializeMeters()
	{
		foreach(VInfoBox meter in meters.Values)
		{
			part.stackIcon.RemoveInfo (meter);	
		}
		meters.Clear ();
		
		if(engineActive) {
			foreach(ModuleEngines.Propellant prop in propellants)
			{
				meters.Add (prop.name, NewMeter(prop.name));
			}
		}
	}

	VInfoBox NewMeter (string resourceName)
	{
		VInfoBox meter = part.stackIcon.DisplayInfo ();
		if (resourceName == "IntakeAir") {
			meter.SetMessage ("Air");
			meter.SetProgressBarColor (XKCDColors.White);
			meter.SetProgressBarBgColor (XKCDColors.Grey);
		} else {
			meter.SetMessage (resourceName);
			meter.SetMsgBgColor (XKCDColors.DarkLime);
			meter.SetMsgTextColor (XKCDColors.ElectricLime);
			meter.SetProgressBarColor (XKCDColors.Yellow);
			meter.SetProgressBarBgColor (XKCDColors.DarkLime);
		}
		meter.SetLength (2f);
		meter.SetValue (0f);
		
		return meter;
	}
	
}

